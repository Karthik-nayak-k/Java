package com.java.empmanagment.model;

public class Employee {
	
	public int id;
	public String empName;
	public String empdepID;
	public String empEmail;
	public String empMobile;
	public String empAddress;
	
	
	public Employee(int id, String empName, String empdepID, String empEmail, String empMobile, String empAddress) {
		super();
		this.id = id;
		this.empName = empName;
		this.empdepID = empdepID;
		this.empEmail = empEmail;
		this.empMobile = empMobile;
		this.empAddress = empAddress;
	}
	
	public Employee(String empName, String empdepID, String empEmail, String empMobile, String empAddress) {
		super();
		this.empName = empName;
		this.empdepID = empdepID;
		this.empEmail = empEmail;
		this.empMobile = empMobile;
		this.empAddress = empAddress;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpdepID() {
		return empdepID;
	}
	public void setEmpdepID(String empdepID) {
		this.empdepID = empdepID;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public String getEmpMobile() {
		return empMobile;
	}
	public void setEmpMobile(String empMobile) {
		this.empMobile = empMobile;
	}
	public String getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}
	
	
}
