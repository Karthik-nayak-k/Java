package com.java.empmanagment.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.java.empmanagment.dao.EmployeeDAO;
import com.java.empmanagment.model.Employee;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/employees")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeeDAO empdao;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EmployeeServlet() {
		super();
		this.empdao = new EmployeeDAO();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("id") != null) {
			doPut(request, response);

		} else {

			String name = request.getParameter("empName");
			String deptid = request.getParameter("empdepID");
			String email = request.getParameter("empEmail");
			String mobile = request.getParameter("empMobile");
			String address = request.getParameter("empAddress");
			Employee emp = new Employee(name, deptid, email, mobile, address);
			empdao.insertUserInfo(emp);

			response.sendRedirect("employees");
		}
	}

	@Override
	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		System.out.println("delete emp id" + id);
		empdao.deleteEmployee(id);
		response.sendRedirect("employees");
	}

	@Override
	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("empName");
		String deptid = request.getParameter("empdepID");
		String email = request.getParameter("empEmail");
		String mobile = request.getParameter("empMobile");
		String address = request.getParameter("empAddress");

		Employee emp = new Employee(id, name, deptid, email, mobile, address);
		empdao.updateEmployee(emp);
		response.sendRedirect("employees");

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();
		System.out.println(action);

		List<Employee> listemp = empdao.selectAllUser();
		// Object listemp = empdao.selectAllUser();
		System.out.println(listemp);
		request.setAttribute("listEmp", listemp);
		RequestDispatcher dispatcher = request.getRequestDispatcher("emp-list.jsp");
		dispatcher.forward(request, response);

	}

}
