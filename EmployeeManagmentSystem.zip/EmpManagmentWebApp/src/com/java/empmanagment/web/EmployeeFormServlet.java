package com.java.empmanagment.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.java.empmanagment.dao.EmployeeDAO;
import com.java.empmanagment.model.Employee;

@WebServlet("/")
public class EmployeeFormServlet extends HttpServlet {
	private EmployeeDAO empdao;
	
	public EmployeeFormServlet() {
		super();
		this.empdao = new EmployeeDAO();
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();
		System.out.println(action);
		switch (action) {
		case "/new":
			showNewForm(request, response); // emp-form.jsp()
			break;

		case "/edit":
			showEditform(request, response); // userInfo()
			break;
			
		case "/delete":
			int id = Integer.parseInt(request.getParameter("id"));
			System.out.println("delete emp id" +id);
			empdao.deleteEmployee(id);
			response.sendRedirect("employees");
			

		}

	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("emp-form.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditform(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		Employee emp = empdao.userInfo(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("emp-form.jsp");
		request.setAttribute("emp", emp);
		dispatcher.forward(request, response);
	}

}
