package com.java.empmanagment.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.empmanagment.model.Employee;

public class EmployeeDAO {

	private static final String connstr = "jdbc:sqlserver://DESKTOP-8EH6SIV\\SQLEXPRESS;databaseName=EmplyoeeDB;user=Karthik;password=karthik1997";

	static {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		} catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		}
	}

	public void insertUserInfo(Employee emps) {

		try (Connection conn = DriverManager.getConnection(connstr)) {
			PreparedStatement pstmt;
			pstmt = conn.prepareStatement("insert into Employee_Detail values(?,?,?,?,?)");
			pstmt.setString(1, emps.getEmpName());
			pstmt.setString(2, emps.getEmpdepID());
			pstmt.setString(3, emps.getEmpEmail());
			pstmt.setString(4, emps.getEmpMobile());
			pstmt.setString(5, emps.getEmpAddress());

			int rows = pstmt.executeUpdate();
			System.out.println(rows + " rows got affected");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Inside insertUserInfo() Execption");
			e.printStackTrace();
		}
	}

	public void updateEmployee(Employee emp) {

		// String
		// connstr="jdbc:sqlserver://DESKTOP-8EH6SIV\\SQLEXPRESS;databaseName=EmplyoeeDB;user=Karthik;password=karthik1997";
		try (Connection conn = DriverManager.getConnection(connstr)) {
			PreparedStatement pstmt;
			pstmt = conn.prepareStatement(
					"update Employee_Detail set emp_name=?,emp_deptID=?,emp_email=?,emp_mobile=?,emp_address=? where emp_Id = ?");
			pstmt.setString(1, emp.getEmpName());
			pstmt.setString(2, emp.getEmpdepID());
			pstmt.setString(3, emp.getEmpEmail());
			pstmt.setString(4, emp.getEmpMobile());
			pstmt.setString(5, emp.getEmpAddress());
			pstmt.setInt(6, emp.getId());

			int row = pstmt.executeUpdate();

			System.out.println(row + " rows got affected");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Inside updateEmployee() Execption");
		}

	}

	public Employee userInfo(int id) {

		Employee emp = null;
		// String
		// connstr="jdbc:sqlserver://DESKTOP-8EH6SIV\\SQLEXPRESS;databaseName=EmplyoeeDB;user=Karthik;password=karthik1997";
		try (Connection conn = DriverManager.getConnection(connstr)) {
			PreparedStatement pstmt;
			pstmt = conn.prepareStatement(
					"select emp_name,emp_deptID,emp_email,emp_mobile,emp_address from Employee_Detail where emp_Id = ?");
			pstmt.setInt(1, id);

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				String name = rs.getString("emp_name");
				String deptid = rs.getString("emp_deptID");
				String email = rs.getString("emp_email");
				String mobile = rs.getString("emp_mobile");
				String address = rs.getString("emp_address");

				emp = new Employee(id, name, deptid, email, mobile, address);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Inside userInfo() Execption");
		}
		return emp;
	}

	public List<Employee> selectAllUser() {

		List<Employee> emp = new ArrayList<>();
		try (Connection conn = DriverManager.getConnection(connstr)) {
			PreparedStatement pstmt;
			pstmt = conn.prepareStatement("select * from Employee_Detail");

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("emp_Id");
				String name = rs.getString("emp_name");
				String deptid = rs.getString("emp_deptID");
				String email = rs.getString("emp_email");
				String mobile = rs.getString("emp_mobile");
				String address = rs.getString("emp_address");

				emp.add(new Employee(id, name, deptid, email, mobile, address));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Inside selectAllUser() Execption");
		}
		return emp;

	}

	public void deleteEmployee(int id) {

		// String
		// connstr="jdbc:sqlserver://DESKTOP-8EH6SIV\\SQLEXPRESS;databaseName=EmplyoeeDB;user=Karthik;password=karthik1997";
		try (Connection conn = DriverManager.getConnection(connstr)) {
			PreparedStatement pstmt;
			pstmt = conn.prepareStatement("delete from Employee_Detail where emp_Id=?");
			pstmt.setInt(1, id);

			int row = pstmt.executeUpdate();
			System.out.println(row + " rows got affected");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Inside deleteEmployee() Execption");
		}
	}

}
